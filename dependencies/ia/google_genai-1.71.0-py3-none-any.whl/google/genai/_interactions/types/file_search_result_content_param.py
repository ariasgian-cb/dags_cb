# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import Base64FileInput
from .._utils import PropertyInfo
from .._models import set_pydantic_config

__all__ = ["FileSearchResultContentParam", "Result"]


class Result(TypedDict, total=False):
    """The result of the File Search."""

    custom_metadata: Iterable[object]
    """User provided metadata about the FileSearchResult."""


class FileSearchResultContentParam(TypedDict, total=False):
    """File Search result content."""

    call_id: Required[str]
    """Required. ID to match the ID from the function call block."""

    result: Required[Iterable[Result]]
    """Required. The results of the File Search."""

    type: Required[Literal["file_search_result"]]

    signature: Annotated[Union[str, Base64FileInput], PropertyInfo(format="base64")]
    """A signature hash for backend validation."""


set_pydantic_config(FileSearchResultContentParam, {"arbitrary_types_allowed": True})
